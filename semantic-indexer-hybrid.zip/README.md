# Hybrid Code Indexer (Semantic + Graph)

**Production-grade** FastAPI service that indexes multi-repo codebases with:
- **Semantic search** via Milvus / Milvus Lite (vector ANN)
- **Graph layer** (symbols & edges) in PostgreSQL
- **Incremental re-indexing** (changed files only) + purge of deleted files
- **Scheduler** (nightly cron) and **GitLab webhook** to trigger indexing
- **Security**: API key, basic rate-limiting
- **Observability**: Prometheus `/metrics`, health/readiness
- Language coverage: **C#/.NET**, **TypeScript/Angular**, **JavaScript**, **Java**, **Python** (extensible via Tree-sitter)

## Quick Start (Dev with Milvus Lite)

```bash
cp .env.example .env
docker compose -f docker-compose.dev.yml up --build
```

Index a repo:
```bash
curl -H "X-API-Key: change-me-please" -H "Content-Type: application/json"   -X POST http://localhost:8080/index -d '{"repo_url":"git@gitlab.example.com:team/project.git","branch":"main"}'
```

Search semantically:
```bash
curl -H "X-API-Key: change-me-please" -H "Content-Type: application/json"   -X POST http://localhost:8080/search -d '{"query":"validate JWT token","top_k":10}'
```

Graph actions:
```bash
# similar by name
curl -H "X-API-Key: change-me-please" -H "Content-Type: application/json"   -X POST http://localhost:8080/graph/similar -d '{"repo_url":"git@gitlab.../project.git","name_like":"ValidateJwt","limit":20}'

# callers of a symbol
curl -H "X-API-Key: change-me-please" -H "Content-Type: application/json"   -X POST http://localhost:8080/graph/callers -d '{"repo_url":"git@gitlab.../project.git","symbol":"ValidateJwt","limit":50}'
```

## Production (Full Milvus)

```bash
docker compose -f docker-compose.prod.yml up -d
```

Then configure your reverse proxy (TLS, auth) and set `API_KEY`.

## Endpoints

- `GET /health` (no auth) — liveness
- `GET /ready` (auth) — readiness (DB + Milvus)
- `GET /metrics` (optional auth) — Prometheus metrics
- `POST /index` (auth) — clone/update, diff, index changed files (semantic + graph), purge deleted
- `POST /search` (auth) — hybrid search (semantic → graph refine → re-rank)
- `POST /graph/similar` (auth) — name/substring symbol search
- `POST /graph/callers` (auth) — callers of a symbol
- `POST /graph/implementations` (auth) — implementations/overrides of a type/symbol
- `POST /gitlab/webhook` (auth) — re-index on push

## Notes

- **Tree-sitter** extractors provide robust symbol/edge parsing for supported languages; you can plug in Roslyn for C# for enterprise-grade precision.
- Add your OpenAI/Azure keys to `.env`.
- Place behind your org’s gateway/SSO for stronger auth.
