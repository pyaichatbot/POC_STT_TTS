# Semantic Code Indexer (FastAPI + Milvus)

Production-grade indexing/search service for large codebases (multi-repo), supporting:
- **Milvus Lite** (developer mode) and **Full Milvus** (production) via Docker Compose
- **Incremental indexing** (only changed files re-embedded)
- **Function-level chunking heuristics** for C#, TypeScript/JavaScript, Python, Java (fallback to line-based chunking)
- **Pluggable embeddings providers** (OpenAI, Azure OpenAI)
- **PostgreSQL** metadata for repos and chunks
- FastAPI endpoints: `/health`, `/index`, `/search`, `/stats`

## Quick Start (Dev - Milvus Lite)

```bash
cp .env.example .env
docker compose -f docker-compose.dev.yml up --build
```

Then call indexing:
```bash
curl -X POST http://localhost:8080/index -H "Content-Type: application/json" -d '{
  "repo_url": "git@gitlab.example.com:team/project.git",
  "branch": "main"
}'
```

Search:
```bash
curl -X POST http://localhost:8080/search -H "Content-Type: application/json" -d '{
  "query": "validate JWT token",
  "top_k": 8
}'
```

## Production (Full Milvus)

```bash
docker compose -f docker-compose.prod.yml up -d
```

Configure environment (see `.env.example`) and ensure **OpenAI** or **Azure OpenAI** keys are set.

## Notes

- For GitLab auth, use SSH with your agent mounted in the container, or HTTPS with a Personal Access Token embedded in the URL or via credentials helper.
- Indexing stores chunk metadata in Postgres and embeddings in Milvus. Query uses embeddings to retrieve top-k code chunks.
- Incremental indexing computes diffs between last indexed commit and HEAD; removed files are purged from DB + Milvus.

## Endpoints

- `GET /health` — readiness check
- `POST /index` — body: `{ repo_url, branch?, clean?, reindex_all? }`
- `POST /search` — body: `{ query, top_k?, repo_url?, path_glob?, lang? }`
- `GET /stats` — overall counts and latest indexed commits

## Data Layout

- Repos are mirrored under `/data/repos/{safe_slug}`
- Postgres tables: `repos`, `chunks`
- Milvus collection: `code_chunks` with FLOAT_VECTOR(1536) default (configurable)

---

**Security**: Put the API behind your internal network, add API auth (e.g., reverse proxy, OAuth) in production. For simplicity, this reference service does not implement auth by default.


## Graph Endpoints (Hybrid)

- `POST /graph/similar` — body: `{ repo_url, name_like, lang?, limit? }`
- `POST /graph/callers` — body: `{ repo_url, symbol, limit? }`

Example:
```bash
curl -X POST http://localhost:8080/graph/similar -H "Content-Type: application/json" -d '{
  "repo_url":"git@gitlab.example.com:team/project.git",
  "name_like":"ValidateJwt",
  "lang":"cs",
  "limit": 20
}'
```
