from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.db.session import AsyncSessionLocal
from app.models.models import Repo
from app.services.graph_store import find_similar_methods, callers_of

router_graph = APIRouter(prefix="/graph", tags=["graph"])

class SimilarReq(BaseModel):
    repo_url: str
    name_like: str
    lang: Optional[str] = None
    limit: int = 20

@router_graph.post("/similar")
async def similar(req: SimilarReq):
    async with AsyncSessionLocal() as session:
        res = await session.execute(select(Repo).where(Repo.url == req.repo_url))
        repo = res.scalars().first()
        if not repo:
            raise HTTPException(404, "repo not indexed")
        syms = await find_similar_methods(session, repo, req.name_like, req.lang)
        out = [{"name": s.name, "kind": s.kind, "rel_path": s.rel_path, "lang": s.lang, "start_line": s.start_line, "end_line": s.end_line, "signature": s.signature} for s in syms[:req.limit]]
        return {"results": out}

class CallersReq(BaseModel):
    repo_url: str
    symbol: str
    limit: int = 50

@router_graph.post("/callers")
async def callers(req: CallersReq):
    async with AsyncSessionLocal() as session:
        res = await session.execute(select(Repo).where(Repo.url == req.repo_url))
        repo = res.scalars().first()
        if not repo:
            raise HTTPException(404, "repo not indexed")
        edges = await callers_of(session, repo, req.symbol)
        out = [{"src_symbol": e.src_symbol, "dst_symbol": e.dst_symbol, "rel_path": e.rel_path, "edge_type": e.edge_type} for e in edges[:req.limit]]
        return {"results": out}
