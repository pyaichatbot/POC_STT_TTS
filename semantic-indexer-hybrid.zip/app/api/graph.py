from fastapi import APIRouter, Depends
from app.core.security import require_api_key
from app.schemas.graph import SimilarRequest, CallersRequest, ImplementationsRequest
from app.services.graph import similar_symbols, callers_of, implementations_of

router = APIRouter(prefix="/graph", tags=["graph"], dependencies=[Depends(require_api_key)])

@router.post("/similar")
async def graph_similar(req: SimilarRequest):
    out = await similar_symbols(req.repo_url, req.name_like, req.lang, req.limit)
    return {"results": out}

@router.post("/callers")
async def graph_callers(req: CallersRequest):
    out = await callers_of(req.repo_url, req.symbol, req.limit)
    return {"results": out}

@router.post("/implementations")
async def graph_impls(req: ImplementationsRequest):
    out = await implementations_of(req.repo_url, req.symbol, req.limit)
    return {"results": out}
