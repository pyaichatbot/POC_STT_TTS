from fastapi import APIRouter, Depends
from app.core.security import require_api_key
from app.schemas.index import IndexRequest, IndexResponse
from app.services.indexer import handle_indexing

router = APIRouter(tags=["indexing"])

@router.post("/index", response_model=IndexResponse, dependencies=[Depends(require_api_key)])
async def index_repo(req: IndexRequest):
    return await handle_indexing(req)
