from fastapi import APIRouter, HTTPException
from app.schemas.index import IndexRequest, IndexResponse
from app.schemas.search import SearchRequest, SearchResponse, SearchHit
from app.services.indexer import handle_indexing
from app.services.searcher import handle_search

router = APIRouter()

@router.get("/health")
async def health():
    return {"status": "ok"}

@router.post("/index", response_model=IndexResponse)
async def index_repo(req: IndexRequest):
    try:
        return await handle_indexing(req)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/search", response_model=SearchResponse)
async def search(req: SearchRequest):
    try:
        return await handle_search(req)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/stats")
async def stats():
    # Minimal placeholder; extend with real stats as needed
    return {"message": "See Postgres for detailed stats."}

# include graph router
from app.api.graph import router_graph
router.include_router(router_graph)
