from fastapi import APIRouter, Depends
from app.core.security import require_api_key

router = APIRouter()

@router.get("/health")
async def health():
    return {"status":"ok"}

@router.get("/ready", dependencies=[Depends(require_api_key)])
async def ready():
    # Light readiness (DB + Milvus ping would be added here)
    return {"status":"ready"}
