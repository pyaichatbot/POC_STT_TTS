from fastapi import APIRouter, Depends
from app.core.security import require_api_key
from app.schemas.search import SearchRequest, SearchResponse
from app.services.searcher import handle_search

router = APIRouter(tags=["search"])

@router.post("/search", response_model=SearchResponse, dependencies=[Depends(require_api_key)])
async def search(req: SearchRequest):
    return await handle_search(req)
