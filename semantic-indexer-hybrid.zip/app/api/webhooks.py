from fastapi import APIRouter, Depends, Header
from app.core.security import require_api_key
from app.schemas.index import IndexRequest
from app.services.indexer import handle_indexing
from app.core.config import settings

router = APIRouter(prefix="/gitlab", tags=["webhooks"], dependencies=[Depends(require_api_key)])

@router.post("/webhook")
async def gitlab_webhook(x_gitlab_token: str | None = Header(None), payload: dict | None = None):
    # Optional: verify x_gitlab_token matches expected
    # For now: just kick index on repo URL from payload['project']['git_ssh_url'] or ['git_http_url']
    if not payload or "project" not in payload:
        return {"status":"ignored"}
    proj = payload["project"]
    repo_url = proj.get("git_ssh_url") or proj.get("git_http_url")
    if not repo_url:
        return {"status":"ignored"}
    req = IndexRequest(repo_url=repo_url, branch=None, reindex_all=False)
    await handle_indexing(req)
    return {"status":"ok"}
