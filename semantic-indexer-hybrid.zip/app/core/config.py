import os
from pydantic import BaseModel

class Settings(BaseModel):
    API_HOST: str = os.getenv("API_HOST", "0.0.0.0")
    API_PORT: int = int(os.getenv("API_PORT", "8080"))
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "info")

    POSTGRES_HOST: str = os.getenv("POSTGRES_HOST", "postgres")
    POSTGRES_PORT: int = int(os.getenv("POSTGRES_PORT", "5432"))
    POSTGRES_DB: str = os.getenv("POSTGRES_DB", "code_indexer")
    POSTGRES_USER: str = os.getenv("POSTGRES_USER", "indexer")
    POSTGRES_PASSWORD: str = os.getenv("POSTGRES_PASSWORD", "indexer_password")

    MILVUS_HOST: str = os.getenv("MILVUS_HOST", "milvus")
    MILVUS_PORT: str = os.getenv("MILVUS_PORT", "19530")
    MILVUS_COLLECTION: str = os.getenv("MILVUS_COLLECTION", "code_chunks")
    MILVUS_DIM: int = int(os.getenv("MILVUS_DIM", "1536"))

    EMBEDDINGS_PROVIDER: str = os.getenv("EMBEDDINGS_PROVIDER", "openai")
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    OPENAI_BASE_URL: str = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
    OPENAI_EMBEDDING_MODEL: str = os.getenv("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small")

    AZURE_OPENAI_ENDPOINT: str = os.getenv("AZURE_OPENAI_ENDPOINT", "")
    AZURE_OPENAI_API_KEY: str = os.getenv("AZURE_OPENAI_API_KEY", "")
    AZURE_OPENAI_EMBEDDING_DEPLOYMENT: str = os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", "")
    AZURE_OPENAI_API_VERSION: str = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")

    EXCLUDE_GLOBS: str = os.getenv("EXCLUDE_GLOBS", "**/node_modules/**,**/.git/**,**/dist/**,**/build/**,**/bin/**,**/obj/**")
    MAX_FILE_BYTES: int = int(os.getenv("MAX_FILE_BYTES", "1048576"))
    DEFAULT_CHUNK_LINES: int = int(os.getenv("DEFAULT_CHUNK_LINES", "120"))
    DEFAULT_CHUNK_OVERLAP: int = int(os.getenv("DEFAULT_CHUNK_OVERLAP", "20"))

settings = Settings()
