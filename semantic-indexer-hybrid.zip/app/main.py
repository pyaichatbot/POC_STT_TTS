import os
import uvicorn
from fastapi import FastAPI
from app.api.routes import router
from app.core.config import settings
from app.db.session import init_db

app = FastAPI(title="Semantic Code Indexer", default_response_class=None)

@app.on_event("startup")
async def startup_event():
    await init_db()

app.include_router(router)

if __name__ == "__main__":
    uvicorn.run("app.main:app", host=settings.API_HOST, port=settings.API_PORT, log_level=settings.LOG_LEVEL, reload=False)
