import uvicorn
from fastapi import FastAPI
from starlette.middleware.cors import CORSMiddleware
from prometheus_client import make_asgi_app
from app.core.config import settings
from app.core.security import limiter
from slowapi.middleware import SlowAPIMiddleware
from app.api.routes import router as base_router
from app.api.indexing import router as indexing_router
from app.api.search import router as search_router
from app.api.graph import router as graph_router
from app.api.webhooks import router as webhook_router
from app.db.session import init_db
from app.services.scheduler import start_scheduler

app = FastAPI(title="Hybrid Code Indexer")
app.state.limiter = limiter
app.add_middleware(SlowAPIMiddleware)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    await init_db()
    if settings.ENABLE_SCHEDULER:
        start_scheduler()

app.include_router(base_router)
app.include_router(indexing_router)
app.include_router(search_router)
app.include_router(graph_router)
app.include_router(webhook_router)

# Prometheus metrics
if settings.ENABLE_PROMETHEUS:
    metrics_app = make_asgi_app()
    app.mount("/metrics", metrics_app)

if __name__ == "__main__":
    uvicorn.run("app.main:app", host=settings.API_HOST, port=settings.API_PORT, log_level=settings.LOG_LEVEL, reload=False)
