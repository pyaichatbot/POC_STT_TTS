import uuid
from sqlalchemy import Column, String, Text, ForeignKey, Index, UniqueConstraint, DateTime
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.db.session import Base

class Symbol(Base):
    __tablename__ = "symbols"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    repo_id = Column(UUID(as_uuid=True), ForeignKey("repos.id", ondelete="CASCADE"), index=True, nullable=False)
    rel_path = Column(Text, nullable=False)
    lang = Column(String(32), nullable=True)
    name = Column(Text, nullable=False)           # fully qualified if available
    kind = Column(String(32), nullable=False)     # function|method|class|interface|module
    start_line = Column(String(32), nullable=True)
    end_line = Column(String(32), nullable=True)
    signature = Column(Text, nullable=True)

    __table_args__ = (
        Index("ix_symbols_repo_path_name", "repo_id", "rel_path", "name"),
        UniqueConstraint("repo_id", "rel_path", "name", name="uq_symbol"),
    )

class Edge(Base):
    __tablename__ = "edges"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    repo_id = Column(UUID(as_uuid=True), ForeignKey("repos.id", ondelete="CASCADE"), index=True, nullable=False)
    src_symbol = Column(Text, nullable=False)
    dst_symbol = Column(Text, nullable=False)
    edge_type = Column(String(32), nullable=False)  # calls|imports|implements|overrides
    rel_path = Column(Text, nullable=True)  # file where edge observed

    __table_args__ = (
        Index("ix_edges_repo_src_dst", "repo_id", "src_symbol", "dst_symbol"),
    )
