import uuid
from sqlalchemy import Column, String, Integer, Text, ForeignKey, Index, UniqueConstraint, DateTime
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.db.session import Base

class Repo(Base):
    __tablename__ = "repos"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    url = Column(Text, nullable=False, unique=True)
    branch = Column(String(128), nullable=True)
    local_path = Column(Text, nullable=False)
    last_indexed_commit = Column(String(64), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now(), server_default=func.now())
    chunks = relationship("Chunk", back_populates="repo", cascade="all, delete-orphan")
    symbols = relationship("Symbol", back_populates="repo", cascade="all, delete-orphan")

class Chunk(Base):
    __tablename__ = "chunks"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    repo_id = Column(UUID(as_uuid=True), ForeignKey("repos.id", ondelete="CASCADE"), index=True, nullable=False)
    rel_path = Column(Text, nullable=False)
    start_line = Column(Integer, nullable=False)
    end_line = Column(Integer, nullable=False)
    lang = Column(String(32), nullable=True)
    content_hash = Column(String(64), nullable=False)
    milvus_id = Column(String(64), nullable=True)
    repo = relationship("Repo", back_populates="chunks")
    __table_args__ = (
        Index("ix_chunks_repo_path", "repo_id", "rel_path"),
        UniqueConstraint("repo_id", "rel_path", "start_line", "end_line", name="uq_chunk_span"),
    )

class Symbol(Base):
    __tablename__ = "symbols"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    repo_id = Column(UUID(as_uuid=True), ForeignKey("repos.id", ondelete="CASCADE"), index=True, nullable=False)
    rel_path = Column(Text, nullable=False)
    start_line = Column(Integer, nullable=False)
    end_line = Column(Integer, nullable=False)
    lang = Column(String(32), nullable=True)
    symbol_name = Column(Text, nullable=False)
    kind = Column(String(32), nullable=False)  # class|method|interface|func|ctor
    signature = Column(Text, nullable=True)    # serialized params/return
    repo = relationship("Repo", back_populates="symbols")
    __table_args__ = (
        Index("ix_symbols_repo_name", "repo_id", "symbol_name"),
    )

class Edge(Base):
    __tablename__ = "edges"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    repo_id = Column(UUID(as_uuid=True), ForeignKey("repos.id", ondelete="CASCADE"), index=True, nullable=False)
    type = Column(String(32), nullable=False)  # calls|imports|implements|overrides
    from_symbol_id = Column(UUID(as_uuid=True), ForeignKey("symbols.id", ondelete="CASCADE"), nullable=False)
    to_symbol_id = Column(UUID(as_uuid=True), ForeignKey("symbols.id", ondelete="CASCADE"), nullable=False)
    __table_args__ = (
        Index("ix_edges_repo_type", "repo_id", "type"),
    )
