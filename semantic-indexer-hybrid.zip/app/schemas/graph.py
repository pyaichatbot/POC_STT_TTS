from pydantic import BaseModel
from typing import Optional, List

class SimilarRequest(BaseModel):
    repo_url: str
    name_like: str
    lang: Optional[str] = None
    limit: int = 20

class CallersRequest(BaseModel):
    repo_url: str
    symbol: str
    limit: int = 50

class ImplementationsRequest(BaseModel):
    repo_url: str
    symbol: str
    limit: int = 50
