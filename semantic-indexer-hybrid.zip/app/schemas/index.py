from pydantic import BaseModel, HttpUrl
from typing import Optional, List

class IndexRequest(BaseModel):
    repo_url: str
    branch: Optional[str] = None
    clean: Optional[bool] = False
    reindex_all: Optional[bool] = False
    include_globs: Optional[List[str]] = None
    exclude_globs: Optional[List[str]] = None

class IndexResponse(BaseModel):
    repo_id: str
    indexed_files: int
    indexed_chunks: int
    last_commit: str
