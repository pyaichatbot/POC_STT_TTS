from pydantic import BaseModel
from typing import Optional, List

class SearchRequest(BaseModel):
    query: str
    top_k: int = 10
    repo_url: Optional[str] = None
    path_glob: Optional[str] = None
    lang: Optional[str] = None

class SearchHit(BaseModel):
    repo_url: str
    rel_path: str
    start_line: int
    end_line: int
    lang: str
    score: float
    snippet: str

class SearchResponse(BaseModel):
    total_results: int
    hits: List[SearchHit]
