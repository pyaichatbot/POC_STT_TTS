import httpx
from tenacity import retry, wait_exponential, stop_after_attempt
from app.core.config import settings

class EmbeddingsClient:
    def __init__(self):
        self.provider = settings.EMBEDDINGS_PROVIDER.lower()

    @retry(wait=wait_exponential(min=1, max=8), stop=stop_after_attempt(5))
    async def embed(self, texts: list[str]) -> list[list[float]]:
        if self.provider == "openai":
            return await self._openai(texts)
        if self.provider == "azure":
            return await self._azure(texts)
        raise RuntimeError(f"Unsupported provider: {self.provider}")

    async def _openai(self, texts: list[str]) -> list[list[float]]:
        headers = {"Authorization": f"Bearer {settings.OPENAI_API_KEY}","Content-Type":"application/json"}
        url = f"{settings.OPENAI_BASE_URL}/embeddings"
        payload = {"input": texts, "model": settings.OPENAI_EMBEDDING_MODEL}
        async with httpx.AsyncClient(timeout=60) as client:
            r = await client.post(url, headers=headers, json=payload)
            r.raise_for_status()
            data = r.json()
            return [d["embedding"] for d in data["data"]]

    async def _azure(self, texts: list[str]) -> list[list[float]]:
        if not settings.AZURE_OPENAI_ENDPOINT or not settings.AZURE_OPENAI_EMBEDDING_DEPLOYMENT:
            raise RuntimeError("Azure OpenAI not configured")
        headers = {"api-key": settings.AZURE_OPENAI_API_KEY, "Content-Type":"application/json"}
        url = f"{settings.AZURE_OPENAI_ENDPOINT}/openai/deployments/{settings.AZURE_OPENAI_EMBEDDING_DEPLOYMENT}/embeddings?api-version={settings.AZURE_OPENAI_API_VERSION}"
        payload = {"input": texts}
        async with httpx.AsyncClient(timeout=60) as client:
            r = await client.post(url, headers=headers, json=payload)
            r.raise_for_status()
            data = r.json()
            return [d["embedding"] for d in data["data"]]
