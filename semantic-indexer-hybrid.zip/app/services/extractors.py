from typing import List, Tuple
from tree_sitter_languages import get_parser

# Returns list of symbols: (name, kind, start_line, end_line, signature)
def extract_symbols(code: str, lang: str) -> List[Tuple[str,str,int,int,str]]:
    # Map to tree-sitter language names
    lang_map = {
        "cs": "c_sharp",
        "ts": "typescript",
        "js": "javascript",
        "py": "python",
        "java": "java",
    }
    ts_lang = lang_map.get(lang)
    if not ts_lang:
        return []
    parser = get_parser(ts_lang)
    tree = parser.parse(bytes(code, "utf-8"))
    root = tree.root_node

    symbols = []
    def add(name, kind, start, end, sig=""):
        symbols.append((name, kind, start+1, end+1, sig))

    def text(node):
        return code[node.start_byte:node.end_byte]

    # Very light extraction per language; extend as needed
    def walk(node):
        t = node.type
        # Methods / functions
        if t in ("method_declaration","function_declaration","function_definition"):
            name_node = None
            for ch in node.children:
                if ch.type in ("identifier","name"):
                    name_node = ch
                    break
            if name_node:
                add(text(name_node), "method", node.start_point[0], node.end_point[0], sig="")
        # Classes / interfaces
        if t in ("class_declaration","interface_declaration","class_definition"):
            name_node = None
            for ch in node.children:
                if ch.type in ("identifier","name"):
                    name_node = ch
                    break
            if name_node:
                add(text(name_node), t.replace("_declaration","").replace("_definition",""), node.start_point[0], node.end_point[0], sig="")
        # Recurse
        for ch in node.children:
            walk(ch)
    walk(root)
    return symbols

# Edge extraction (calls/imports) is simplified; real-world: use language semantics
def extract_edges(code: str, lang: str, symbols: List[Tuple[str,str,int,int,str]]):
    edges = []  # (type, from_symbol_name, to_symbol_name)
    # Naive call detection by name presence inside a method body
    for s_name, kind, s_start, s_end, sig in symbols:
        if kind != "method":
            continue
        body = "\n".join(code.splitlines()[s_start-1:s_end])
        for t_name, t_kind, *_ in symbols:
            if t_name == s_name:
                continue
            if t_name in body:
                edges.append(("calls", s_name, t_name))
    return edges
