from sqlalchemy import select
from app.db.session import AsyncSessionLocal
from app.models.models import Repo, Symbol, Edge

async def similar_symbols(repo_url: str, name_like: str, lang: str | None, limit: int):
    async with AsyncSessionLocal() as session:
        res = await session.execute(select(Repo).where(Repo.url == repo_url))
        repo = res.scalars().first()
        if not repo: return []
        q = select(Symbol).where(Symbol.repo_id == repo.id)
        if lang:
            q = q.where(Symbol.lang == lang)
        # naive substring match (pg_trgm can be added later)
        rows = await session.execute(q)
        out = []
        for s in rows.scalars():
            if name_like.lower() in s.symbol_name.lower():
                out.append({
                    "symbol_name": s.symbol_name,
                    "kind": s.kind,
                    "rel_path": s.rel_path,
                    "start_line": s.start_line,
                    "end_line": s.end_line,
                    "lang": s.lang
                })
            if len(out) >= limit:
                break
        return out

async def callers_of(repo_url: str, symbol_name: str, limit: int):
    async with AsyncSessionLocal() as session:
        res = await session.execute(select(Repo).where(Repo.url == repo_url))
        repo = res.scalars().first()
        if not repo: return []
        # Find the symbol
        sres = await session.execute(select(Symbol).where(Symbol.repo_id == repo.id, Symbol.symbol_name == symbol_name))
        target = sres.scalars().first()
        if not target: return []
        # All edges calls -> to target
        eres = await session.execute(select(Edge, Symbol).join(Symbol, Edge.from_symbol_id == Symbol.id).where(Edge.repo_id == repo.id, Edge.type == "calls", Edge.to_symbol_id == target.id))
        out = []
        for e, src_sym in eres.all():
            out.append({
                "caller": src_sym.symbol_name,
                "rel_path": src_sym.rel_path,
                "start_line": src_sym.start_line,
                "end_line": src_sym.end_line,
                "lang": src_sym.lang
            })
            if len(out) >= limit:
                break
        return out

async def implementations_of(repo_url: str, symbol_name: str, limit: int):
    # Placeholder: would require richer type info; return symbols with similar names for now
    return await similar_symbols(repo_url, symbol_name, None, limit)
