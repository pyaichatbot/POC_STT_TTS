import re
from typing import List, Tuple

# Simple heuristic extractors. For production, replace with Roslyn (C#) and TS compiler API.

def extract_symbols_ts(code: str) -> List[Tuple[str,str,int,int,str]]:
    # returns list of (name, kind, start_line, end_line, signature)
    lines = code.splitlines()
    out = []
    for i,l in enumerate(lines):
        m = re.search(r'class\s+(\w+)', l)
        if m: out.append((m.group(1), "class", i+1, i+1, l.strip()))
        m = re.search(r'(?:export\s+)?function\s+(\w+)\s*\((.*?)\)', l)
        if m: out.append((m.group(1), "function", i+1, i+1, f"{m.group(1)}({m.group(2)})"))
        m = re.search(r'(\w+)\s*=\s*\((.*?)\)\s*=>', l)
        if m: out.append((m.group(1), "function", i+1, i+1, f"{m.group(1)}({m.group(2)})"))
    return out

def extract_edges_ts(code: str, symbols: List[Tuple[str,str,int,int,str]]) -> List[Tuple[str,str,str]]:
    # returns list of (src_symbol, dst_symbol, edge_type)
    edges = []
    # naive call pattern: foo( ... )
    calls = re.findall(r'([A-Za-z_][A-Za-z0-9_]*)\s*\(', code)
    # Deduplicate trivial JS/TS keywords
    skip = set(['if','for','while','switch','return','function','console','catch','map','filter','reduce','class','new'])
    defs = {s[0] for s in symbols}
    for c in calls:
        if c not in skip:
            # link unknown callee as dst_symbol; src is ambiguous in heuristics
            edges.append(("", c, "calls"))
    # imports
    imps = re.findall(r'import\s+.*?from\s+[\"\'](.*?)[\"\']', code)
    for m in imps:
        edges.append(("", m, "imports"))
    return edges

def extract_symbols_cs(code: str) -> List[Tuple[str,str,int,int,str]]:
    lines = code.splitlines()
    out = []
    for i,l in enumerate(lines):
        m = re.search(r'\b(class|interface|struct)\s+(\w+)', l)
        if m: out.append((m.group(2), m.group(1), i+1, i+1, l.strip()))
        m = re.search(r'(public|private|protected|internal|static|virtual|override|async|\s)+\s*[A-Za-z0-9_<>,\[\]]+\s+(\w+)\s*\((.*?)\)', l)
        if m: out.append((m.group(2), "method", i+1, i+1, f"{m.group(2)}({m.group(3)})"))
    return out

def extract_edges_cs(code: str, symbols: List[Tuple[str,str,int,int,str]]) -> List[Tuple[str,str,str]]:
    edges = []
    # calls: SomeMethod(...)
    calls = re.findall(r'([A-Za-z_][A-Za-z0-9_]*)\s*\(', code)
    skip = set(['if','for','while','switch','return','new','typeof','nameof'])
    for c in calls:
        if c not in skip:
            edges.append(("", c, "calls"))
    # using/imports
    imps = re.findall(r'using\s+([A-Za-z0-9_.]+);', code)
    for m in imps:
        edges.append(("", m, "imports"))
    return edges

def extract_symbols_py(code: str) -> List[Tuple[str,str,int,int,str]]:
    lines = code.splitlines()
    out = []
    for i,l in enumerate(lines):
        m = re.match(r'\s*class\s+(\w+)', l)
        if m: out.append((m.group(1), "class", i+1, i+1, l.strip()))
        m = re.match(r'\s*def\s+(\w+)\s*\((.*?)\)', l)
        if m: out.append((m.group(1), "function", i+1, i+1, f"{m.group(1)}({m.group(2)})"))
    return out

def extract_edges_py(code: str, symbols: List[Tuple[str,str,int,int,str]]) -> List[Tuple[str,str,str]]:
    edges = []
    calls = re.findall(r'([A-Za-z_][A-Za-z0-9_]*)\s*\(', code)
    skip = set(['if','for','while','return','print','range'])
    for c in calls:
        if c not in skip:
            edges.append(("", c, "calls"))
    imps = re.findall(r'from\s+([A-Za-z0-9_.]+)\s+import|import\s+([A-Za-z0-9_.]+)', code)
    for a,b in imps:
        pkg = a or b
        if pkg:
            edges.append(("", pkg, "imports"))
    return edges

def extract(lang: str, code: str):
    if lang in ('ts','js'):
        syms = extract_symbols_ts(code)
        edges = extract_edges_ts(code, syms)
    elif lang == 'cs':
        syms = extract_symbols_cs(code)
        edges = extract_edges_cs(code, syms)
    elif lang == 'py':
        syms = extract_symbols_py(code)
        edges = extract_edges_py(code, syms)
    else:
        syms, edges = [], []
    return syms, edges
