from typing import List, Tuple
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, delete
from app.models.models import Repo
from app.models.graph import Symbol, Edge

async def upsert_graph(session: AsyncSession, repo: Repo, rel_path: str, lang: str, syms: List[tuple], edges: List[tuple]):
    # Remove existing rows for this file
    await session.execute(delete(Symbol).where(Symbol.repo_id == repo.id, Symbol.rel_path == rel_path))
    await session.execute(delete(Edge).where(Edge.repo_id == repo.id, Edge.rel_path == rel_path))

    # Insert new symbols
    for name, kind, start_line, end_line, signature in syms:
        session.add(Symbol(repo_id=repo.id, rel_path=rel_path, lang=lang, name=name, kind=kind,
                           start_line=str(start_line), end_line=str(end_line), signature=signature))

    # Insert edges
    for src, dst, edge_type in edges:
        session.add(Edge(repo_id=repo.id, rel_path=rel_path, src_symbol=src or "", dst_symbol=dst, edge_type=edge_type))

async def find_similar_methods(session: AsyncSession, repo: Repo, name_like: str, lang: str | None = None) -> list[Symbol]:
    q = select(Symbol).where(Symbol.repo_id == repo.id, Symbol.name.ilike(f"%{name_like}%"))
    if lang:
        from sqlalchemy import and_
        q = q.where(Symbol.lang == lang)
    res = await session.execute(q)
    return list(res.scalars())

async def callers_of(session: AsyncSession, repo: Repo, symbol_name: str) -> list[Edge]:
    q = select(Edge).where(Edge.repo_id == repo.id, Edge.dst_symbol == symbol_name, Edge.edge_type == "calls")
    res = await session.execute(q)
    return list(res.scalars())

async def implementations_of(session: AsyncSession, repo: Repo, iface_name: str) -> list[Edge]:
    q = select(Edge).where(Edge.repo_id == repo.id, Edge.dst_symbol == iface_name, Edge.edge_type.in_(["implements","overrides"]))
    res = await session.execute(q)
    return list(res.scalars())
