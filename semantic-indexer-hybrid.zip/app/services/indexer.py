import os, hashlib, fnmatch
from typing import List, Tuple
from sqlalchemy import select, delete
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import AsyncSessionLocal
from app.models.models import Repo, Chunk, Symbol, Edge
from app.utils.gitops import ensure_repo_mirror, get_head_commit, diff_changed_files
from app.utils.files import iter_files
from app.utils.chunking import detect_lang, method_chunks_heuristic, line_chunks
from app.services.embeddings import EmbeddingsClient
from app.services.vectorstore import upsert_vectors, delete_by_chunk_ids
from app.services.extractors import extract_symbols, extract_edges
from app.core.config import settings

def sha256_text(t: str) -> str:
    return hashlib.sha256(t.encode("utf-8")).hexdigest()

async def _get_or_create_repo(session: AsyncSession, url: str, branch: str | None, local_path: str) -> Repo:
    res = await session.execute(select(Repo).where(Repo.url == url))
    repo = res.scalars().first()
    if repo:
        repo.branch = branch
        repo.local_path = local_path
        return repo
    repo = Repo(url=url, branch=branch, local_path=local_path)
    session.add(repo)
    await session.flush()
    return repo

async def _purge_deleted_files(session: AsyncSession, repo: Repo):
    # Remove chunks and symbols whose files no longer exist
    q = select(Chunk).where(Chunk.repo_id == repo.id)
    res = await session.execute(q)
    chunks = list(res.scalars())
    missing_paths = set()
    for c in chunks:
        full = os.path.join(repo.local_path, c.rel_path)
        if not os.path.exists(full):
            missing_paths.add(c.rel_path)
    if missing_paths:
        # Delete chunks
        del_q = select(Chunk.id).where(Chunk.repo_id == repo.id, Chunk.rel_path.in_(list(missing_paths)))
        res = await session.execute(del_q)
        ids = [str(x[0]) for x in res.all()]
        delete_by_chunk_ids(ids)
        await session.execute(delete(Chunk).where(Chunk.id.in_(ids)))
        # Delete symbols and edges for missing files
        sym_q = select(Symbol.id).where(Symbol.repo_id == repo.id, Symbol.rel_path.in_(list(missing_paths)))
        res = await session.execute(sym_q)
        sids = [x[0] for x in res.all()]
        if sids:
            await session.execute(delete(Edge).where((Edge.from_symbol_id.in_(sids)) | (Edge.to_symbol_id.in_(sids))))
            await session.execute(delete(Symbol).where(Symbol.id.in_(sids)))

async def _index_file(session: AsyncSession, repo: Repo, rel_path: str, emb: EmbeddingsClient, batch_entities: list) -> tuple[int,int,int]:
    full = os.path.join(repo.local_path, rel_path)
    try:
        with open(full, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
    except Exception:
        return (0,0,0)
    lang = detect_lang(rel_path)
    chunks = method_chunks_heuristic(text, lang) or line_chunks(text, settings.DEFAULT_CHUNK_LINES, settings.DEFAULT_CHUNK_OVERLAP)
    if not chunks:
        return (0,0,0)
    vecs = await emb.embed([c[2] for c in chunks])

    # Replace existing chunks for file
    res = await session.execute(select(Chunk).where(Chunk.repo_id == repo.id, Chunk.rel_path == rel_path))
    existing = list(res.scalars())
    if existing:
        await session.execute(delete(Chunk).where(Chunk.id.in_([c.id for c in existing])))

    created_chunks=0
    for (start,end,snip), vec in zip(chunks, vecs):
        chash = sha256_text(snip)
        c = Chunk(repo_id=repo.id, rel_path=rel_path, start_line=start, end_line=end, lang=lang, content_hash=chash)
        session.add(c); await session.flush()
        batch_entities.append({
            "chunk_id": str(c.id),
            "repo_url": repo.url,
            "rel_path": rel_path,
            "start_line": start,
            "end_line": end,
            "lang": lang,
            "content_hash": chash,
            "embedding": vec,
        })
        created_chunks += 1

    # Symbols + Edges
    # Remove old symbols for file
    res = await session.execute(select(Symbol).where(Symbol.repo_id == repo.id, Symbol.rel_path == rel_path))
    old_syms = list(res.scalars())
    old_ids = [s.id for s in old_syms]
    if old_ids:
        await session.execute(delete(Edge).where((Edge.from_symbol_id.in_(old_ids)) | (Edge.to_symbol_id.in_(old_ids))))
        await session.execute(delete(Symbol).where(Symbol.id.in_(old_ids)))

    symbols = extract_symbols(text, lang)
    created_symbols = 0
    name_to_id = {}
    for name, kind, s_line, e_line, sig in symbols:
        s = Symbol(repo_id=repo.id, rel_path=rel_path, start_line=s_line, end_line=e_line, lang=lang, symbol_name=name, kind=kind, signature=sig)
        session.add(s); await session.flush()
        name_to_id[name] = s.id
        created_symbols += 1
    edges = []
    for et, src, dst in extract_edges(text, lang, symbols):
        if src in name_to_id and dst in name_to_id:
            edges.append(Edge(repo_id=repo.id, type=et, from_symbol_id=name_to_id[src], to_symbol_id=name_to_id[dst]))
    if edges:
        session.add_all(edges)

    return (1, created_chunks, created_symbols)

async def handle_indexing(req):
    base_dir = "/data/repos"; os.makedirs(base_dir, exist_ok=True)
    worktree = ensure_repo_mirror(base_dir, req.repo_url, req.branch)
    head = get_head_commit(worktree)

    exclude = [e.strip() for e in (req.exclude_globs or (settings.EXCLUDE_GLOBS.split(','))) if e.strip()]
    include = req.include_globs

    async with AsyncSessionLocal() as session:
        repo = await _get_or_create_repo(session, req.repo_url, req.branch, worktree)
        prev_commit = repo.last_indexed_commit
        # Determine changed files
        if req.reindex_all or not prev_commit:
            changed = list(iter_files(worktree, include, exclude, settings.MAX_FILE_BYTES))
        else:
            diff = diff_changed_files(worktree, prev_commit, head)
            # apply include/exclude & size
            changed = []
            for rel in diff:
                full = os.path.join(worktree, rel)
                if not os.path.exists(full): 
                    continue
                if include and not any(fnmatch.fnmatch(rel, pat) for pat in include):
                    continue
                if exclude and any(fnmatch.fnmatch(rel, pat) for pat in exclude):
                    continue
                try:
                    if os.path.getsize(full) > settings.MAX_FILE_BYTES:
                        continue
                except FileNotFoundError:
                    continue
                changed.append(rel)

        emb = EmbeddingsClient()
        files_count = 0; chunks_count = 0; symbols_count = 0
        batch_entities = []

        for rel in changed:
            repo.local_path = worktree  # ensure current path
            f, c, s = await _index_file(session, repo, rel, emb, batch_entities)
            files_count += f; chunks_count += c; symbols_count += s
            if len(batch_entities) >= 512:
                upsert_vectors(batch_entities); batch_entities.clear()

        if batch_entities:
            upsert_vectors(batch_entities)

        # Purge deleted files
        await _purge_deleted_files(session, repo)

        repo.last_indexed_commit = head
        await session.commit()

        return {"repo_id": str(repo.id), "indexed_files": files_count, "indexed_chunks": chunks_count, "indexed_symbols": symbols_count, "last_commit": head}
