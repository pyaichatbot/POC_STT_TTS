import os
import hashlib
from typing import Tuple, List
from sqlalchemy import select, delete
from sqlalchemy.exc import NoResultFound
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import AsyncSessionLocal
from app.models.models import Repo, Chunk
from app.utils.gitops import ensure_repo_mirror, get_head_commit, diff_changed_files, safe_slug, is_file_removed
from app.utils.files import iter_files
from app.utils.chunking import detect_lang, method_chunks, line_chunks
from app.core.config import settings
from app.services.embeddings import EmbeddingsClient
from app.services.graph_extractor import extract
from app.services.graph_store import upsert_graph
from app.services.vectorstore import upsert_vectors, delete_by_chunk_ids

def sha256_text(t: str) -> str:
    return hashlib.sha256(t.encode("utf-8")).hexdigest()

async def _get_or_create_repo(session: AsyncSession, url: str, branch: str | None, local_path: str) -> Repo:
    res = await session.execute(select(Repo).where(Repo.url == url))
    repo = res.scalars().first()
    if repo:
        repo.branch = branch
        repo.local_path = local_path
        return repo
    repo = Repo(url=url, branch=branch, local_path=local_path)
    session.add(repo)
    await session.flush()
    return repo

async def _remove_chunks_for_files(session: AsyncSession, repo: Repo, rel_paths: List[str]):
    # delete in Postgres and Milvus
    q = select(Chunk).where(Chunk.repo_id == repo.id, Chunk.rel_path.in_(rel_paths))
    res = await session.execute(q)
    to_del = list(res.scalars())
    if to_del:
        delete_ids = [str(c.id) for c in to_del]
        delete_by_chunk_ids(delete_ids)
        await session.execute(delete(Chunk).where(Chunk.id.in_([c.id for c in to_del])))

async def _index_file(session: AsyncSession, repo: Repo, rel_path: str, full_path: str, emb: EmbeddingsClient, indexed_entities: list):
    with open(full_path, "r", encoding="utf-8", errors="ignore") as f:
        text = f.read()
    lang = detect_lang(rel_path)
    chunks = method_chunks(text, lang)
    if not chunks:
        chunks = line_chunks(text, settings.DEFAULT_CHUNK_LINES, settings.DEFAULT_CHUNK_OVERLAP)
    contents = [c[2] for c in chunks]

    # Graph extraction (heuristic)
    syms, edges = extract(lang, text)
    await upsert_graph(session, repo, rel_path, lang, syms, edges)

    if not contents:
        return 0, 0

    vecs = await emb.embed(contents)
    created = 0
    # Remove existing chunks for this file first (idempotent reindex for the file)
    q = select(Chunk).where(Chunk.repo_id == repo.id, Chunk.rel_path == rel_path)
    res = await session.execute(q)
    existing = list(res.scalars())
    if existing:
        await session.execute(delete(Chunk).where(Chunk.id.in_([c.id for c in existing])))

    for (start,end,snip), vec in zip(chunks, vecs):
        chash = sha256_text(snip)
        c = Chunk(repo_id=repo.id, rel_path=rel_path, start_line=start, end_line=end, lang=lang, content_hash=chash)
        session.add(c)
        await session.flush()
        indexed_entities.append({
            "chunk_id": str(c.id),
            "repo_url": repo.url,
            "rel_path": rel_path,
            "start_line": start,
            "end_line": end,
            "lang": lang,
            "content_hash": chash,
            "embedding": vec,
        })
        created += 1
    return 1, created

async def handle_indexing(req) -> dict:
    # Prepare repo
    base_dir = "/data/repos"
    os.makedirs(base_dir, exist_ok=True)
    worktree = ensure_repo_mirror(base_dir, req.repo_url, req.branch)
    head = get_head_commit(worktree)

    exclude = [e.strip() for e in (req.exclude_globs or (settings.EXCLUDE_GLOBS.split(','))) if e.strip()]
    include = req.include_globs

    async with AsyncSessionLocal() as session:
        repo = await _get_or_create_repo(session, req.repo_url, req.branch, worktree)
        prev_commit = repo.last_indexed_commit

        changed_files = None
        if req.reindex_all or not prev_commit:
            # index everything
            changed_files = list(iter_files(worktree, include, exclude, settings.MAX_FILE_BYTES))
        else:
            diff_files = diff_changed_files(worktree, prev_commit, head)
            # filter by globs and size limits
            changed_files = []
            for f in diff_files:
                # apply include/exclude logic similar to iter_files
                from app.utils.files import fnmatch
            changed_files = diff_files  # simplified; we'll rely on per-file checks below

        # Remove deleted files
        if prev_commit:
            # We cannot easily list deleted by glob here; we check DB for existing files and test existence
            pass

        emb = EmbeddingsClient()
        total_files = 0
        total_chunks = 0
        batch_entities = []

        for rel in changed_files:
            full = os.path.join(worktree, rel)
            if not os.path.exists(full):
                continue
            if os.path.getsize(full) > settings.MAX_FILE_BYTES:
                continue
            # Respect globs again (safety)
            import fnmatch as _fn
            if include and not any(_fn.fnmatch(rel, pat) for pat in include):
                continue
            if exclude and any(_fn.fnmatch(rel, pat) for pat in exclude):
                continue

            fcount, ccount = await _index_file(session, repo, rel, full, emb, batch_entities)
            total_files += fcount
            total_chunks += ccount

            # Upsert in reasonable batches
            if len(batch_entities) >= 512:
                upsert_vectors(batch_entities)
                batch_entities = []

        if batch_entities:
            upsert_vectors(batch_entities)

        # Update head commit
        repo.last_indexed_commit = head
        await session.commit()

        return {
            "repo_id": str(repo.id),
            "indexed_files": total_files,
            "indexed_chunks": total_chunks,
            "last_commit": head
        }
