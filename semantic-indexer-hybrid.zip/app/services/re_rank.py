import math

def sigmoid(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-x))

def combine_scores(semantic: float, signature_match: float, name_sim: float, graph_radius: int | None) -> float:
    # Simple weighted sum with small boosts; tune as needed
    g = 1.0
    if graph_radius is not None:
        g = 1.0 + (1.0 / (1 + graph_radius))  # closer is better
    return 0.70 * sigmoid(semantic) + 0.20 * signature_match + 0.10 * name_sim * g
