import os
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from app.core.config import settings
from app.schemas.index import IndexRequest
from app.services.indexer import handle_indexing

scheduler = AsyncIOScheduler()

def start_scheduler():
    if not settings.ENABLE_SCHEDULER:
        return
    cron = settings.SCHEDULE_CRON
    repos = [r.strip() for r in (settings.SCHEDULED_REPOS.split(",") if settings.SCHEDULED_REPOS else []) if r.strip()]
    if not repos:
        return
    def job_factory(repo_url: str):
        async def job():
            req = IndexRequest(repo_url=repo_url, branch=settings.DEFAULT_BRANCH, reindex_all=False)
            await handle_indexing(req)
        return job
    for r in repos:
        scheduler.add_job(job_factory(r), CronTrigger.from_crontab(cron))
    scheduler.start()
