from typing import Optional, Dict
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import AsyncSessionLocal
from app.models.models import Repo, Chunk
from app.services.embeddings import EmbeddingsClient
from app.services.vectorstore import search_vectors

async def handle_search(req):
    emb = EmbeddingsClient()
    qvec = (await emb.embed([req.query]))[0]

    filters: Dict[str,str] = {}
    if req.repo_url:
        filters["repo_url"] = req.repo_url
    if req.lang:
        filters["lang"] = req.lang

    hits = search_vectors(qvec, req.top_k, filters or None)

    # Enrich with snippet text by querying DB (we didn't store text in DB for size reasons; but we can reconstruct)
    # For now, we read from filesystem based on repo url mapping in DB.
    results = []
    async with AsyncSessionLocal() as session:
        for h in hits:
            res = await session.execute(select(Repo).where(Repo.url == h["repo_url"]))
            repo = res.scalars().first()
            if not repo:
                snippet = ""
            else:
                import os
                full = os.path.join(repo.local_path, h["rel_path"])
                try:
                    with open(full, "r", encoding="utf-8", errors="ignore") as f:
                        lines = f.readlines()
                    start = max(0, h["start_line"] - 1)
                    end = min(len(lines), h["end_line"])
                    snippet = "".join(lines[start:end])
                except Exception:
                    snippet = ""

            results.append({
                "repo_url": h["repo_url"],
                "rel_path": h["rel_path"],
                "start_line": h["start_line"],
                "end_line": h["end_line"],
                "lang": h["lang"],
                "score": h["score"],
                "snippet": snippet
            })

    return {"total_results": len(results), "hits": results}
