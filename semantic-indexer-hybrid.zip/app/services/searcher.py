import os
from typing import Dict, List
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import AsyncSessionLocal
from app.models.models import Repo, Symbol
from app.services.embeddings import EmbeddingsClient
from app.services.vectorstore import search_vectors
from app.services.re_rank import combine_scores

async def handle_search(req):
    emb = EmbeddingsClient()
    qvec = (await emb.embed([req.query]))[0]

    filters: Dict[str,str] = {}
    if req.repo_url:
        filters["repo_url"] = req.repo_url
    if req.lang:
        filters["lang"] = req.lang

    vec_hits = search_vectors(qvec, req.top_k*3, filters or None)  # overfetch
    results = []
    async with AsyncSessionLocal() as session:
        # Build symbol name cache for re-ranking
        for h in vec_hits:
            res = await session.execute(select(Repo).where(Repo.url == h["repo_url"]))
            repo = res.scalars().first()
            if not repo:
                continue
            full = os.path.join(repo.local_path, h["rel_path"])
            snippet = ""
            try:
                with open(full, "r", encoding="utf-8", errors="ignore") as f:
                    lines = f.readlines()
                start = max(0, h["start_line"] - 1)
                end = min(len(lines), h["end_line"])
                snippet = "".join(lines[start:end])
            except Exception:
                pass

            # Simple name/sig boosts by overlapping words
            name_sim = 0.0
            signature_match = 0.0
            # If symbol table has an entry overlapping this span, give a boost
            sym = await session.execute(select(Symbol).where(Symbol.repo_id == repo.id, Symbol.rel_path == h["rel_path"], Symbol.start_line <= h["start_line"], Symbol.end_line >= h["end_line"]))
            s = sym.scalars().first()
            if s:
                qlower = req.query.lower()
                if s.symbol_name.lower() in qlower or any(tok in s.symbol_name.lower() for tok in qlower.split()):
                    name_sim = 1.0
                if s.signature and any(tok in (s.signature.lower()) for tok in qlower.split()):
                    signature_match = 0.5

            score = combine_scores(h["score"], signature_match, name_sim, graph_radius=1)  # assume close for now
            results.append({
                "repo_url": h["repo_url"], "rel_path": h["rel_path"],
                "start_line": h["start_line"], "end_line": h["end_line"],
                "lang": h["lang"], "score": score, "snippet": snippet
            })

    results.sort(key=lambda x: x["score"], reverse=True)
    results = results[:req.top_k]
    return {"total_results": len(results), "hits": results}
