from typing import List, Dict, Any, Optional
from pymilvus import connections, Collection, FieldSchema, CollectionSchema, DataType, utility
from app.core.config import settings

def connect():
    connections.connect(alias="default", host=settings.MILVUS_HOST, port=settings.MILVUS_PORT)

def ensure_collection() -> Collection:
    connect()
    name = settings.MILVUS_COLLECTION
    dim = settings.MILVUS_DIM
    if not utility.has_collection(name):
        fields = [
            FieldSchema(name="chunk_id", dtype=DataType.VARCHAR, is_primary=True, max_length=64, auto_id=False),
            FieldSchema(name="repo_url", dtype=DataType.VARCHAR, max_length=512),
            FieldSchema(name="rel_path", dtype=DataType.VARCHAR, max_length=1024),
            FieldSchema(name="start_line", dtype=DataType.INT32),
            FieldSchema(name="end_line", dtype=DataType.INT32),
            FieldSchema(name="lang", dtype=DataType.VARCHAR, max_length=32),
            FieldSchema(name="content_hash", dtype=DataType.VARCHAR, max_length=64),
            FieldSchema(name="embedding", dtype=DataType.FLOAT_VECTOR, dim=dim),
        ]
        schema = CollectionSchema(fields, description="Code chunks embeddings")
        coll = Collection(name=name, schema=schema, consistency_level="Session")
        coll.create_index("embedding", {"index_type": "HNSW", "metric_type": "IP", "params": {"M": 32, "efConstruction": 200}})
        return coll
    return Collection(name=name)

def upsert_vectors(entities: List[Dict[str,Any]]):
    coll = ensure_collection()
    data = [
        [e["chunk_id"] for e in entities],
        [e["repo_url"] for e in entities],
        [e["rel_path"] for e in entities],
        [e["start_line"] for e in entities],
        [e["end_line"] for e in entities],
        [e.get("lang","") for e in entities],
        [e["content_hash"] for e in entities],
        [e["embedding"] for e in entities],
    ]
    coll.upsert(data)
    coll.flush()

def delete_by_chunk_ids(chunk_ids: List[str]):
    coll = ensure_collection()
    if not chunk_ids:
        return
    expr = f'chunk_id in {chunk_ids}'
    coll.delete(expr)

def delete_by_repo(repo_url: str):
    coll = ensure_collection()
    expr = f'repo_url == "{repo_url}"'
    coll.delete(expr)

def search_vectors(query_vec: List[float], top_k: int, filters: Optional[Dict[str,str]] = None):
    coll = ensure_collection()
    params = {"metric_type": "IP", "params": {"ef": 128}}
    expr = None
    if filters:
        clauses = []
        for k,v in filters.items():
            if k in ("repo_url","lang"):
                clauses.append(f'{k} == "{v}"')
        if clauses:
            expr = " and ".join(clauses)
    res = coll.search([query_vec], "embedding", param=params, limit=top_k, expr=expr,
                      output_fields=["repo_url","rel_path","start_line","end_line","lang","content_hash"])
    hits = []
    for rh in res[0]:
        fields = rh.fields
        hits.append({
            "score": float(rh.score),
            "repo_url": fields["repo_url"],
            "rel_path": fields["rel_path"],
            "start_line": fields["start_line"],
            "end_line": fields["end_line"],
            "lang": fields["lang"],
            "content_hash": fields["content_hash"],
            "chunk_id": rh.id,
        })
    return hits
