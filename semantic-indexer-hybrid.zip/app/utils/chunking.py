import re
from typing import List, Tuple

def detect_lang(rel_path: str) -> str:
    p = rel_path.lower()
    if p.endswith(('.ts', '.tsx')): return 'ts'
    if p.endswith(('.js', '.jsx')): return 'js'
    if p.endswith('.py'): return 'py'
    if p.endswith('.cs'): return 'cs'
    if p.endswith('.java'): return 'java'
    if p.endswith('.go'): return 'go'
    if p.endswith('.rb'): return 'rb'
    if p.endswith('.php'): return 'php'
    if p.endswith('.cpp') or p.endswith('.hpp') or p.endswith('.cc') or p.endswith('.cxx'): return 'cpp'
    if p.endswith('.c') or p.endswith('.h'): return 'c'
    if p.endswith('.rs'): return 'rs'
    return 'txt'

def method_chunks(text: str, lang: str) -> List[Tuple[int,int,str]]:
    # Heuristic function-level chunking; fallback to line-based if not matched
    lines = text.splitlines()
    chunks = []
    if lang in ('py',):
        # naive: split on def/class
        indices = [i for i,l in enumerate(lines) if re.match(r'\s*(def |class )', l)]
    elif lang in ('ts','js'):
        indices = [i for i,l in enumerate(lines) if re.search(r'function\s+|=>\s*\(|class\s+|\bconstructor\s*\(', l)]
    elif lang in ('cs', 'java'):
        indices = [i for i,l in enumerate(lines) if re.search(r'\b(class|interface|struct)\s+|\b[A-Za-z0-9_<>\[\]]+\s+[A-Za-z0-9_]+\s*\(', l)]
    else:
        indices = []

    if indices:
        indices.append(len(lines))
        for a,b in zip(indices, indices[1:]):
            start = a+1
            end = b
            snippet = "\n".join(lines[a:b])
            if snippet.strip():
                chunks.append((start, end, snippet))
        return chunks

    # Fallback line-based
    return []

def line_chunks(text: str, max_lines: int, overlap: int) -> List[Tuple[int,int,str]]:
    lines = text.splitlines()
    chunks = []
    n = len(lines)
    i = 0
    while i < n:
        start = i + 1
        end = min(i + max_lines, n)
        snippet = "\n".join(lines[i:end])
        if snippet.strip():
            chunks.append((start, end, snippet))
        if end == n:
            break
        i = end - overlap
        if i < 0: i = 0
    return chunks
