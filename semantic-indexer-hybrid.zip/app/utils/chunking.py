import re
from typing import List, Tuple

def detect_lang(rel_path: str) -> str:
    p = rel_path.lower()
    if p.endswith(('.ts','.tsx')): return 'ts'
    if p.endswith(('.js','.jsx')): return 'js'
    if p.endswith('.py'): return 'py'
    if p.endswith('.cs'): return 'cs'
    if p.endswith('.java'): return 'java'
    return 'txt'

def method_chunks_heuristic(text: str, lang: str) -> List[Tuple[int,int,str]]:
    lines = text.splitlines()
    idx = []
    if lang == 'py':
        idx = [i for i,l in enumerate(lines) if re.match(r'\s*(def |class )', l)]
    elif lang in ('ts','js'):
        idx = [i for i,l in enumerate(lines) if re.search(r'function\s+|=>\s*\(|class\s+|\bconstructor\s*\(', l)]
    elif lang in ('cs','java'):
        idx = [i for i,l in enumerate(lines) if re.search(r'\b(class|interface|struct)\s+|\b[A-Za-z0-9_<>\[\]]+\s+[A-Za-z0-9_]+\s*\(', l)]
    if idx:
        idx.append(len(lines))
        chunks = []
        for a,b in zip(idx, idx[1:]):
            s = a+1; e = b
            snippet = "\n".join(lines[a:b])
            if snippet.strip():
                chunks.append((s,e,snippet))
        return chunks
    return []

def line_chunks(text: str, max_lines: int, overlap: int) -> List[Tuple[int,int,str]]:
    lines = text.splitlines()
    out=[]; i=0; n=len(lines)
    while i < n:
        s=i+1; e=min(i+max_lines,n)
        sn="\n".join(lines[i:e])
        if sn.strip(): out.append((s,e,sn))
        if e==n: break
        i = max(0, e-overlap)
    return out
