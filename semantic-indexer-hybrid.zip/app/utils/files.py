import os, fnmatch
from typing import Iterator, List

def iter_files(root: str, include_globs: list[str] | None, exclude_globs: list[str] | None, max_bytes: int) -> Iterator[str]:
    for dirpath, dirnames, filenames in os.walk(root):
        rel_dir = os.path.relpath(dirpath, root)
        # Apply directory-level excludes early
        if exclude_globs:
            skip_dir = False
            for pat in exclude_globs:
                if fnmatch.fnmatch(os.path.join(rel_dir, ''), pat) or fnmatch.fnmatch(dirpath, pat):
                    skip_dir = True
                    break
            if skip_dir:
                continue

        for f in filenames:
            full = os.path.join(dirpath, f)
            rel = os.path.relpath(full, root)
            if exclude_globs and any(fnmatch.fnmatch(rel, pat) for pat in exclude_globs):
                continue
            if include_globs and not any(fnmatch.fnmatch(rel, pat) for pat in include_globs):
                continue
            if os.path.getsize(full) > max_bytes:
                continue
            yield rel
