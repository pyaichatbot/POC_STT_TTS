import os, fnmatch
from typing import Iterator

def iter_files(root: str, include_globs: list[str] | None, exclude_globs: list[str] | None, max_bytes: int) -> Iterator[str]:
    for dirpath, dirnames, filenames in os.walk(root):
        rel_dir = os.path.relpath(dirpath, root)
        for f in filenames:
            full = os.path.join(dirpath, f)
            rel = os.path.relpath(full, root)
            if exclude_globs and any(fnmatch.fnmatch(rel, pat) for pat in exclude_globs):
                continue
            if include_globs and not any(fnmatch.fnmatch(rel, pat) for pat in include_globs):
                continue
            try:
                if os.path.getsize(full) > max_bytes:
                    continue
            except FileNotFoundError:
                continue
            yield rel
