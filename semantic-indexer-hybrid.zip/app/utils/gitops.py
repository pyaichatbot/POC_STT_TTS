import os, shlex, subprocess
from pathlib import Path
from typing import Optional

def safe_slug(url: str) -> str:
    return url.replace("://","_").replace("/","_").replace(":","_")

def run(cmd: str, cwd: Optional[str] = None):
    proc = subprocess.run(shlex.split(cmd), cwd=cwd, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError(f"Command failed: {cmd}\nSTDOUT: {proc.stdout}\nSTDERR: {proc.stderr}")
    return proc.stdout.strip()

def ensure_repo_mirror(base_dir: str, url: str, branch: Optional[str] = None) -> str:
    Path(base_dir).mkdir(parents=True, exist_ok=True)
    mirror_dir = os.path.join(base_dir, safe_slug(url))
    if not os.path.exists(mirror_dir):
        run(f"git clone --mirror {shlex.quote(url)} {shlex.quote(mirror_dir)}")
    else:
        run("git remote update", cwd=mirror_dir)
    worktree_dir = os.path.join(base_dir, safe_slug(url) + "_worktree")
    if not os.path.exists(worktree_dir):
        os.makedirs(worktree_dir, exist_ok=True)
        run(f"git --git-dir={mirror_dir} worktree add {worktree_dir} {branch or 'HEAD'}")
    else:
        run("git fetch", cwd=worktree_dir)
        if branch:
            run(f"git checkout {branch}", cwd=worktree_dir)
        run("git pull", cwd=worktree_dir)
    return worktree_dir

def get_head_commit(path: str) -> str:
    return run("git rev-parse HEAD", cwd=path)

def diff_changed_files(path: str, from_commit: str, to_commit: str) -> list[str]:
    if not from_commit or from_commit == to_commit:
        return []
    out = run(f"git diff --name-only {from_commit} {to_commit}", cwd=path)
    return [x.strip() for x in out.splitlines() if x.strip()]
