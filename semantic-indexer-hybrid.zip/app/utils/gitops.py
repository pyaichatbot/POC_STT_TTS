import os
import subprocess
import shlex
from pathlib import Path
from typing import Optional

def safe_slug(url: str) -> str:
    slug = url.replace("://", "_").replace("/", "_").replace(":", "_")
    return slug

def run(cmd: str, cwd: Optional[str] = None, env: Optional[dict] = None):
    proc = subprocess.run(shlex.split(cmd), cwd=cwd, env=env, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError(f"Command failed: {cmd}\nSTDOUT: {proc.stdout}\nSTDERR: {proc.stderr}")
    return proc.stdout.strip()

def ensure_repo_mirror(base_dir: str, url: str, branch: Optional[str] = None) -> str:
    Path(base_dir).mkdir(parents=True, exist_ok=True)
    target = os.path.join(base_dir, safe_slug(url))
    if not os.path.exists(target):
        run(f"git clone --mirror {shlex.quote(url)} {shlex.quote(target)}")
    else:
        run("git remote update", cwd=target)
    # Worktree for branch
    worktree_dir = os.path.join(base_dir, safe_slug(url) + "_worktree")
    if not os.path.exists(worktree_dir):
        os.makedirs(worktree_dir, exist_ok=True)
        run(f"git --git-dir={target} worktree add {worktree_dir} {branch or 'HEAD'}")
    else:
        # pull latest
        run("git fetch", cwd=worktree_dir)
        if branch:
            run(f"git checkout {branch}", cwd=worktree_dir)
        run("git pull", cwd=worktree_dir)
    return worktree_dir

def get_head_commit(path: str) -> str:
    out = run("git rev-parse HEAD", cwd=path)
    return out

def diff_changed_files(path: str, from_commit: str, to_commit: str) -> list[str]:
    if from_commit == to_commit:
        return []
    out = run(f"git diff --name-only {from_commit} {to_commit}", cwd=path)
    files = [l.strip() for l in out.splitlines() if l.strip()]
    return files

def is_file_removed(path: str, repo_path: str) -> bool:
    return not os.path.exists(os.path.join(repo_path, path))
